module Neat
  VERSION = '1.7.2'
end
